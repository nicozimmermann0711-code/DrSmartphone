/**
 * Dr. Smartphone 48 - Premium Booking System
 * Device Picker with Interactive Hotspots
 */

// ============================================
// STATE MANAGEMENT
// ============================================
const BookingState = {
  currentStep: 1,
  selectedCategory: 'smartphones',
  selectedBrand: null,
  selectedDevice: null,
  selectedAreas: [],
  selectedServices: [],
  selectedDate: null,
  selectedTime: null,
  contact: {
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
    notes: ''
  },
  bookingCode: null
};

// Data stores
let devicesData = null;
let servicesData = null;

// ============================================
// DATA LOADING
// ============================================
async function loadData() {
  try {
    const [devicesRes, servicesRes] = await Promise.all([
      fetch('/assets/data/devices.json'),
      fetch('/assets/data/services.json')
    ]);
    
    devicesData = await devicesRes.json();
    servicesData = await servicesRes.json();
    
    initializeApp();
  } catch (error) {
    console.error('Failed to load data:', error);
    showError('Daten konnten nicht geladen werden. Bitte laden Sie die Seite neu.');
  }
}

// ============================================
// INITIALIZATION
// ============================================
function initializeApp() {
  renderCategoryTabs();
  renderBrandFilters();
  renderDeviceGrid();
  initializeCalendar();
  initializeTimeSlots();
  bindEvents();
}

// ============================================
// CATEGORY & BRAND FILTERS
// ============================================
function renderCategoryTabs() {
  const tabs = document.getElementById('category-tabs');
  if (!tabs) return;
  
  tabs.querySelectorAll('.category-tab').forEach(tab => {
    tab.classList.toggle('active', tab.dataset.category === BookingState.selectedCategory);
  });
}

function renderBrandFilters() {
  const container = document.getElementById('brand-filters');
  if (!container || !devicesData) return;
  
  const brands = devicesData.brands[BookingState.selectedCategory] || [];
  
  container.innerHTML = `
    <button class="filter-chip ${!BookingState.selectedBrand ? 'active' : ''}" data-brand="">
      Alle Marken
    </button>
    ${brands.map(brand => `
      <button class="filter-chip ${BookingState.selectedBrand === brand ? 'active' : ''}" data-brand="${brand}">
        ${brand}
      </button>
    `).join('')}
  `;
}

// ============================================
// DEVICE GRID
// ============================================
function renderDeviceGrid() {
  const grid = document.getElementById('device-grid');
  if (!grid || !devicesData) return;
  
  const searchQuery = document.getElementById('device-search')?.value.toLowerCase() || '';
  
  let devices = devicesData.devices.filter(d => d.category === BookingState.selectedCategory);
  
  if (BookingState.selectedBrand) {
    devices = devices.filter(d => d.brand === BookingState.selectedBrand);
  }
  
  if (searchQuery) {
    devices = devices.filter(d => 
      d.model.toLowerCase().includes(searchQuery) ||
      d.brand.toLowerCase().includes(searchQuery)
    );
  }
  
  if (devices.length === 0) {
    grid.innerHTML = `
      <div class="empty-state" style="grid-column: 1 / -1;">
        <div class="empty-state-icon">
          <svg width="64" height="64" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
            <circle cx="11" cy="11" r="8"/>
            <path d="m21 21-4.35-4.35"/>
          </svg>
        </div>
        <p>Keine Geräte gefunden</p>
      </div>
    `;
    return;
  }
  
  grid.innerHTML = devices.map(device => `
    <div class="device-card ${BookingState.selectedDevice?.id === device.id ? 'selected' : ''}" 
         data-device-id="${device.id}"
         tabindex="0"
         role="button"
         aria-label="${device.brand} ${device.model} auswählen">
      <div class="device-card-image">
        <div class="device-placeholder ${device.aspect}">
          ${getDeviceSVG(device.aspect, device.brand)}
        </div>
      </div>
      <div class="device-card-body">
        <div class="device-card-brand">${device.brand}</div>
        <div class="device-card-name">${device.model}</div>
      </div>
    </div>
  `).join('');
}

function getDeviceSVG(aspect, brand) {
  const brandColors = {
    'Apple': '#A2AAAD',
    'Samsung': '#1428A0',
    'Google': '#4285F4',
    'Sony': '#003087',
    'Microsoft': '#00A4EF',
    'Nintendo': '#E60012'
  };
  
  const color = brandColors[brand] || 'var(--color-accent)';
  
  switch (aspect) {
    case 'phone':
      return `
        <svg viewBox="0 0 60 120" fill="none" xmlns="http://www.w3.org/2000/svg" style="width: 60%; height: auto;">
          <rect x="2" y="2" width="56" height="116" rx="8" fill="var(--color-bg-elevated)" stroke="${color}" stroke-width="2"/>
          <rect x="6" y="10" width="48" height="95" rx="2" fill="var(--color-bg-deep)"/>
          <circle cx="30" cy="6" r="2" fill="${color}" opacity="0.5"/>
          <rect x="20" y="110" width="20" height="4" rx="2" fill="${color}" opacity="0.3"/>
        </svg>
      `;
    case 'tablet':
      return `
        <svg viewBox="0 0 120 90" fill="none" xmlns="http://www.w3.org/2000/svg" style="width: 80%; height: auto;">
          <rect x="2" y="2" width="116" height="86" rx="6" fill="var(--color-bg-elevated)" stroke="${color}" stroke-width="2"/>
          <rect x="8" y="8" width="104" height="74" rx="2" fill="var(--color-bg-deep)"/>
          <circle cx="60" cy="4" r="2" fill="${color}" opacity="0.5"/>
        </svg>
      `;
    case 'console':
      return `
        <svg viewBox="0 0 140 80" fill="none" xmlns="http://www.w3.org/2000/svg" style="width: 80%; height: auto;">
          <rect x="2" y="2" width="136" height="76" rx="4" fill="var(--color-bg-elevated)" stroke="${color}" stroke-width="2"/>
          <rect x="10" y="15" width="30" height="8" rx="2" fill="${color}" opacity="0.3"/>
          <circle cx="70" cy="40" r="15" fill="var(--color-bg-deep)" stroke="${color}" stroke-width="1"/>
          <rect x="100" y="35" width="30" height="10" rx="2" fill="${color}" opacity="0.3"/>
        </svg>
      `;
    case 'controller':
      return `
        <svg viewBox="0 0 140 80" fill="none" xmlns="http://www.w3.org/2000/svg" style="width: 80%; height: auto;">
          <path d="M20 20 Q2 25 2 45 Q2 70 25 75 L55 78 Q70 80 85 78 L115 75 Q138 70 138 45 Q138 25 120 20 Q100 15 70 15 Q40 15 20 20Z" 
                fill="var(--color-bg-elevated)" stroke="${color}" stroke-width="2"/>
          <circle cx="35" cy="40" r="12" fill="var(--color-bg-deep)" stroke="${color}" stroke-width="1"/>
          <circle cx="105" cy="40" r="12" fill="var(--color-bg-deep)" stroke="${color}" stroke-width="1"/>
          <circle cx="70" cy="50" r="6" fill="${color}" opacity="0.3"/>
        </svg>
      `;
    default:
      return '';
  }
}

// ============================================
// DEVICE SELECTION & HOTSPOTS
// ============================================
function selectDevice(deviceId) {
  const device = devicesData.devices.find(d => d.id === deviceId);
  if (!device) return;
  
  BookingState.selectedDevice = device;
  BookingState.selectedAreas = [];
  
  // Update UI
  document.querySelectorAll('.device-card').forEach(card => {
    card.classList.toggle('selected', card.dataset.deviceId === deviceId);
  });
  
  // Show device viewer panel
  const viewerPanel = document.getElementById('device-viewer-panel');
  const deviceGrid = document.getElementById('device-grid');
  
  if (viewerPanel && deviceGrid) {
    deviceGrid.classList.add('hidden');
    viewerPanel.classList.remove('hidden');
    viewerPanel.classList.add('animate-fade-in-up');
  }
  
  // Update device info
  document.getElementById('selected-device-brand').textContent = device.brand;
  document.getElementById('selected-device-model').textContent = device.model;
  
  // Render device with hotspots
  renderDeviceWithHotspots(device);
  updateSelectedAreasList();
  updateStepNavigation();
}

function renderDeviceWithHotspots(device) {
  const container = document.getElementById('device-image-container');
  if (!container) return;
  
  const aspectClass = device.aspect === 'tablet' ? 'tablet' : 
                      device.aspect === 'console' ? 'console' :
                      device.aspect === 'controller' ? 'controller' : '';
  
  container.innerHTML = `
    <div class="device-viewer" style="position: relative;">
      <div class="device-placeholder ${aspectClass}" style="min-height: 300px;">
        ${getDeviceSVG(device.aspect, device.brand)}
      </div>
      <div class="hotspot-overlay">
        ${device.hotspots.map(hotspot => `
          <button class="hotspot ${BookingState.selectedAreas.includes(hotspot.id) ? 'active' : ''}"
                  data-hotspot-id="${hotspot.id}"
                  style="left: ${hotspot.x * 100}%; top: ${hotspot.y * 100}%; width: ${hotspot.w * 100}%; height: ${hotspot.h * 100}%;"
                  aria-label="${hotspot.label}"
                  tabindex="0">
            <span class="hotspot-label">${hotspot.label}</span>
          </button>
        `).join('')}
      </div>
    </div>
  `;
}

function toggleHotspot(hotspotId) {
  const device = BookingState.selectedDevice;
  if (!device) return;
  
  const hotspot = device.hotspots.find(h => h.id === hotspotId);
  if (!hotspot) return;
  
  const index = BookingState.selectedAreas.indexOf(hotspotId);
  
  if (index === -1) {
    BookingState.selectedAreas.push(hotspotId);
  } else {
    BookingState.selectedAreas.splice(index, 1);
  }
  
  // Update hotspot visual
  document.querySelectorAll('.hotspot').forEach(el => {
    el.classList.toggle('active', BookingState.selectedAreas.includes(el.dataset.hotspotId));
  });
  
  updateSelectedAreasList();
  updateStepNavigation();
}

function updateSelectedAreasList() {
  const container = document.getElementById('selected-areas-list');
  if (!container) return;
  
  const device = BookingState.selectedDevice;
  
  if (BookingState.selectedAreas.length === 0) {
    container.innerHTML = '<span class="text-muted">Noch keine Bereiche ausgewählt</span>';
    return;
  }
  
  container.innerHTML = BookingState.selectedAreas.map(areaId => {
    const hotspot = device?.hotspots.find(h => h.id === areaId);
    return `
      <span class="area-tag">
        ${hotspot?.label || areaId}
        <span class="area-tag-remove" data-area-id="${areaId}">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3">
            <path d="M18 6L6 18M6 6l12 12"/>
          </svg>
        </span>
      </span>
    `;
  }).join('');
}

function removeArea(areaId) {
  const index = BookingState.selectedAreas.indexOf(areaId);
  if (index > -1) {
    BookingState.selectedAreas.splice(index, 1);
    
    document.querySelectorAll('.hotspot').forEach(el => {
      el.classList.toggle('active', BookingState.selectedAreas.includes(el.dataset.hotspotId));
    });
    
    updateSelectedAreasList();
    updateStepNavigation();
  }
}

// ============================================
// SERVICE SELECTION
// ============================================
function renderServiceList() {
  const container = document.getElementById('service-list');
  if (!container || !servicesData) return;
  
  const device = BookingState.selectedDevice;
  if (!device) return;
  
  // Get default services from selected hotspots
  const defaultServiceIds = new Set();
  BookingState.selectedAreas.forEach(areaId => {
    const hotspot = device.hotspots.find(h => h.id === areaId);
    if (hotspot?.defaultServices) {
      hotspot.defaultServices.forEach(sid => defaultServiceIds.add(sid));
    }
  });
  
  // Pre-select these services
  BookingState.selectedServices = [...defaultServiceIds];
  
  // Filter services for this device category
  const relevantServices = servicesData.services.filter(service => 
    service.supportedCategories.includes(device.category)
  );
  
  container.innerHTML = relevantServices.map(service => {
    const isSelected = BookingState.selectedServices.includes(service.id);
    const price = calculateServicePrice(service, device);
    
    return `
      <div class="service-item ${isSelected ? 'selected' : ''}" 
           data-service-id="${service.id}"
           tabindex="0"
           role="checkbox"
           aria-checked="${isSelected}">
        <div class="service-checkbox">
          <svg viewBox="0 0 24 24" fill="none">
            <path d="M20 6L9 17l-5-5"/>
          </svg>
        </div>
        <div class="service-info">
          <div class="service-name">${service.name}</div>
          <div class="service-desc">${service.description}</div>
        </div>
        <div class="service-price">${formatPrice(price)}</div>
      </div>
    `;
  }).join('');
  
  updateStepNavigation();
}

function toggleService(serviceId) {
  const index = BookingState.selectedServices.indexOf(serviceId);
  
  if (index === -1) {
    BookingState.selectedServices.push(serviceId);
  } else {
    BookingState.selectedServices.splice(index, 1);
  }
  
  // Update visual
  document.querySelectorAll('.service-item').forEach(el => {
    const isSelected = BookingState.selectedServices.includes(el.dataset.serviceId);
    el.classList.toggle('selected', isSelected);
    el.setAttribute('aria-checked', isSelected);
  });
  
  updateStepNavigation();
}

function calculateServicePrice(service, device) {
  const basePrice = service.basePriceCents;
  const factor = device?.priceFactor || 1;
  return Math.round(basePrice * factor);
}

// ============================================
// QUOTE CALCULATION
// ============================================
function renderQuote() {
  const device = BookingState.selectedDevice;
  if (!device || !servicesData) return;
  
  // Update device info
  document.getElementById('quote-device-brand').textContent = device.brand;
  document.getElementById('quote-device-model').textContent = device.model;
  
  // Calculate line items
  const lines = BookingState.selectedServices.map(serviceId => {
    const service = servicesData.services.find(s => s.id === serviceId);
    if (!service) return null;
    
    const price = calculateServicePrice(service, device);
    return { name: service.name, price };
  }).filter(Boolean);
  
  // Render lines
  const linesContainer = document.getElementById('quote-lines');
  const subtotal = lines.reduce((sum, line) => sum + line.price, 0);
  const vat = Math.round(subtotal * 0.19);
  const total = subtotal + vat;
  
  linesContainer.innerHTML = `
    ${lines.map(line => `
      <div class="quote-line">
        <span class="quote-line-label">${line.name}</span>
        <span class="quote-line-value">${formatPrice(line.price)}</span>
      </div>
    `).join('')}
    <div class="quote-line" style="border-top: 1px solid var(--color-border); padding-top: var(--space-4); margin-top: var(--space-2);">
      <span class="quote-line-label">Zwischensumme</span>
      <span class="quote-line-value">${formatPrice(subtotal)}</span>
    </div>
    <div class="quote-line">
      <span class="quote-line-label">MwSt. (19%)</span>
      <span class="quote-line-value">${formatPrice(vat)}</span>
    </div>
  `;
  
  document.getElementById('quote-total').textContent = formatPrice(total);
}

function formatPrice(cents) {
  return new Intl.NumberFormat('de-DE', {
    style: 'currency',
    currency: 'EUR'
  }).format(cents / 100);
}

// ============================================
// CALENDAR
// ============================================
let currentCalendarDate = new Date();

function initializeCalendar() {
  renderCalendar();
}

function renderCalendar() {
  const titleEl = document.getElementById('cal-title');
  const gridEl = document.getElementById('cal-grid');
  if (!titleEl || !gridEl) return;
  
  const year = currentCalendarDate.getFullYear();
  const month = currentCalendarDate.getMonth();
  
  const monthNames = ['Januar', 'Februar', 'März', 'April', 'Mai', 'Juni', 
                      'Juli', 'August', 'September', 'Oktober', 'November', 'Dezember'];
  
  titleEl.textContent = `${monthNames[month]} ${year}`;
  
  const weekdays = ['Mo', 'Di', 'Mi', 'Do', 'Fr', 'Sa', 'So'];
  const firstDay = new Date(year, month, 1);
  const lastDay = new Date(year, month + 1, 0);
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  
  // Adjust first day to Monday-based week
  let startDay = firstDay.getDay() - 1;
  if (startDay < 0) startDay = 6;
  
  let html = weekdays.map(d => `<div class="calendar-weekday">${d}</div>`).join('');
  
  // Empty cells before first day
  for (let i = 0; i < startDay; i++) {
    html += '<div class="calendar-day disabled"></div>';
  }
  
  // Days of month
  for (let day = 1; day <= lastDay.getDate(); day++) {
    const date = new Date(year, month, day);
    const dateStr = date.toISOString().split('T')[0];
    const isToday = date.getTime() === today.getTime();
    const isPast = date < today;
    const isWeekend = date.getDay() === 0 || date.getDay() === 6;
    const isSelected = BookingState.selectedDate === dateStr;
    const isDisabled = isPast || isWeekend;
    
    html += `
      <div class="calendar-day ${isToday ? 'today' : ''} ${isSelected ? 'selected' : ''} ${isDisabled ? 'disabled' : ''}"
           data-date="${dateStr}"
           ${isDisabled ? '' : 'tabindex="0" role="button"'}>
        ${day}
      </div>
    `;
  }
  
  gridEl.innerHTML = html;
}

function selectDate(dateStr) {
  BookingState.selectedDate = dateStr;
  renderCalendar();
  updateSelectedDateTime();
  updateStepNavigation();
}

// ============================================
// TIME SLOTS
// ============================================
function initializeTimeSlots() {
  const container = document.getElementById('time-slots');
  if (!container) return;
  
  const slots = [
    '09:00', '09:30', '10:00', '10:30', '11:00', '11:30',
    '12:00', '12:30', '14:00', '14:30', '15:00', '15:30',
    '16:00', '16:30', '17:00', '17:30', '18:00', '18:30'
  ];
  
  container.innerHTML = slots.map(time => `
    <button class="time-slot ${BookingState.selectedTime === time ? 'selected' : ''}" 
            data-time="${time}"
            tabindex="0">
      ${time}
    </button>
  `).join('');
}

function selectTime(time) {
  BookingState.selectedTime = time;
  
  document.querySelectorAll('.time-slot').forEach(el => {
    el.classList.toggle('selected', el.dataset.time === time);
  });
  
  updateSelectedDateTime();
  updateStepNavigation();
}

function updateSelectedDateTime() {
  const card = document.getElementById('selected-datetime-card');
  const display = document.getElementById('selected-datetime');
  
  if (!card || !display) return;
  
  if (BookingState.selectedDate && BookingState.selectedTime) {
    const date = new Date(BookingState.selectedDate);
    const formatted = date.toLocaleDateString('de-DE', {
      weekday: 'long',
      day: 'numeric',
      month: 'long',
      year: 'numeric'
    });
    
    display.textContent = `${formatted} um ${BookingState.selectedTime} Uhr`;
    card.style.display = 'block';
  } else {
    card.style.display = 'none';
  }
}

// ============================================
// STEP NAVIGATION
// ============================================
function goToStep(step) {
  if (step < 1 || step > 6) return;
  
  BookingState.currentStep = step;
  
  // Update step content visibility
  document.querySelectorAll('.step-content').forEach((el, index) => {
    el.classList.toggle('active', index + 1 === step);
  });
  
  // Update progress stepper
  document.querySelectorAll('.progress-step').forEach(el => {
    const stepNum = parseInt(el.dataset.step);
    el.classList.toggle('active', stepNum === step);
    el.classList.toggle('completed', stepNum < step);
  });
  
  document.querySelectorAll('.progress-connector').forEach((el, index) => {
    el.classList.toggle('completed', index + 1 < step);
  });
  
  // Step-specific rendering
  if (step === 2) renderServiceList();
  if (step === 3) renderQuote();
  
  // Scroll to top
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

function updateStepNavigation() {
  const step1Next = document.getElementById('step1-next');
  const continueBtn = document.getElementById('continue-to-services');
  const step2Next = document.getElementById('step2-next');
  const step4Next = document.getElementById('step4-next');
  
  // Step 1: Need device and at least one area selected
  const step1Valid = BookingState.selectedDevice && BookingState.selectedAreas.length > 0;
  if (step1Next) step1Next.disabled = !step1Valid;
  if (continueBtn) continueBtn.disabled = !step1Valid;
  
  // Step 2: Need at least one service
  const step2Valid = BookingState.selectedServices.length > 0;
  if (step2Next) step2Next.disabled = !step2Valid;
  
  // Step 4: Need date and time
  const step4Valid = BookingState.selectedDate && BookingState.selectedTime;
  if (step4Next) step4Next.disabled = !step4Valid;
}

// ============================================
// BOOKING SUBMISSION
// ============================================
function submitBooking() {
  // Collect contact info
  BookingState.contact = {
    firstName: document.getElementById('first-name')?.value || '',
    lastName: document.getElementById('last-name')?.value || '',
    email: document.getElementById('email')?.value || '',
    phone: document.getElementById('phone')?.value || '',
    notes: document.getElementById('notes')?.value || ''
  };
  
  // Validate
  if (!BookingState.contact.firstName || !BookingState.contact.lastName || 
      !BookingState.contact.email || !BookingState.contact.phone) {
    alert('Bitte füllen Sie alle Pflichtfelder aus.');
    return;
  }
  
  if (!document.getElementById('terms')?.checked) {
    alert('Bitte akzeptieren Sie die Datenschutzerklärung und AGB.');
    return;
  }
  
  // Generate booking code
  const year = new Date().getFullYear();
  const orderNum = Math.floor(1000 + Math.random() * 9000);
  BookingState.bookingCode = `DS48-${year}-${orderNum}`;
  
  // Save to localStorage (demo)
  saveOrder();
  
  // Show confirmation
  document.getElementById('booking-code').textContent = BookingState.bookingCode;
  goToStep(6);
}

function saveOrder() {
  const orders = JSON.parse(localStorage.getItem('ds48_orders') || '[]');
  
  const order = {
    code: BookingState.bookingCode,
    device: {
      id: BookingState.selectedDevice.id,
      brand: BookingState.selectedDevice.brand,
      model: BookingState.selectedDevice.model
    },
    areas: BookingState.selectedAreas,
    services: BookingState.selectedServices,
    appointment: {
      date: BookingState.selectedDate,
      time: BookingState.selectedTime
    },
    contact: BookingState.contact,
    status: 'received',
    timeline: [
      { status: 'received', timestamp: new Date().toISOString(), note: 'Auftrag eingegangen' }
    ],
    createdAt: new Date().toISOString()
  };
  
  orders.push(order);
  localStorage.setItem('ds48_orders', JSON.stringify(orders));
}

// ============================================
// EVENT BINDING
// ============================================
function bindEvents() {
  // Category tabs
  document.getElementById('category-tabs')?.addEventListener('click', (e) => {
    const tab = e.target.closest('.category-tab');
    if (!tab) return;
    
    BookingState.selectedCategory = tab.dataset.category;
    BookingState.selectedBrand = null;
    BookingState.selectedDevice = null;
    BookingState.selectedAreas = [];
    
    // Reset view
    document.getElementById('device-viewer-panel')?.classList.add('hidden');
    document.getElementById('device-grid')?.classList.remove('hidden');
    
    renderCategoryTabs();
    renderBrandFilters();
    renderDeviceGrid();
    updateStepNavigation();
  });
  
  // Brand filters
  document.getElementById('brand-filters')?.addEventListener('click', (e) => {
    const chip = e.target.closest('.filter-chip');
    if (!chip) return;
    
    BookingState.selectedBrand = chip.dataset.brand || null;
    renderBrandFilters();
    renderDeviceGrid();
  });
  
  // Device search
  document.getElementById('device-search')?.addEventListener('input', () => {
    renderDeviceGrid();
  });
  
  // Device grid
  document.getElementById('device-grid')?.addEventListener('click', (e) => {
    const card = e.target.closest('.device-card');
    if (card) selectDevice(card.dataset.deviceId);
  });
  
  // Device viewer hotspots
  document.getElementById('device-image-container')?.addEventListener('click', (e) => {
    const hotspot = e.target.closest('.hotspot');
    if (hotspot) toggleHotspot(hotspot.dataset.hotspotId);
  });
  
  // Remove area tags
  document.getElementById('selected-areas-list')?.addEventListener('click', (e) => {
    const removeBtn = e.target.closest('.area-tag-remove');
    if (removeBtn) removeArea(removeBtn.dataset.areaId);
  });
  
  // Change device button
  document.getElementById('change-device-btn')?.addEventListener('click', () => {
    document.getElementById('device-viewer-panel')?.classList.add('hidden');
    document.getElementById('device-grid')?.classList.remove('hidden');
  });
  
  // Continue to services button
  document.getElementById('continue-to-services')?.addEventListener('click', () => {
    if (BookingState.selectedDevice && BookingState.selectedAreas.length > 0) {
      goToStep(2);
    }
  });
  
  // Service list
  document.getElementById('service-list')?.addEventListener('click', (e) => {
    const item = e.target.closest('.service-item');
    if (item) toggleService(item.dataset.serviceId);
  });
  
  // Calendar navigation
  document.getElementById('cal-prev')?.addEventListener('click', () => {
    currentCalendarDate.setMonth(currentCalendarDate.getMonth() - 1);
    renderCalendar();
  });
  
  document.getElementById('cal-next')?.addEventListener('click', () => {
    currentCalendarDate.setMonth(currentCalendarDate.getMonth() + 1);
    renderCalendar();
  });
  
  // Calendar day selection
  document.getElementById('cal-grid')?.addEventListener('click', (e) => {
    const day = e.target.closest('.calendar-day:not(.disabled)');
    if (day && day.dataset.date) selectDate(day.dataset.date);
  });
  
  // Time slot selection
  document.getElementById('time-slots')?.addEventListener('click', (e) => {
    const slot = e.target.closest('.time-slot:not(.disabled)');
    if (slot) selectTime(slot.dataset.time);
  });
  
  // Step navigation buttons
  document.getElementById('step1-next')?.addEventListener('click', () => goToStep(2));
  document.getElementById('step2-back')?.addEventListener('click', () => goToStep(1));
  document.getElementById('step2-next')?.addEventListener('click', () => goToStep(3));
  document.getElementById('step3-back')?.addEventListener('click', () => goToStep(2));
  document.getElementById('step3-next')?.addEventListener('click', () => goToStep(4));
  document.getElementById('step4-back')?.addEventListener('click', () => goToStep(3));
  document.getElementById('step4-next')?.addEventListener('click', () => goToStep(5));
  document.getElementById('step5-back')?.addEventListener('click', () => goToStep(4));
  document.getElementById('step5-submit')?.addEventListener('click', submitBooking);
  
  // Keyboard navigation for hotspots
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' || e.key === ' ') {
      const hotspot = document.activeElement.closest('.hotspot');
      if (hotspot) {
        e.preventDefault();
        toggleHotspot(hotspot.dataset.hotspotId);
      }
      
      const deviceCard = document.activeElement.closest('.device-card');
      if (deviceCard) {
        e.preventDefault();
        selectDevice(deviceCard.dataset.deviceId);
      }
    }
  });
}

function showError(message) {
  // Simple error display
  const container = document.querySelector('.booking-main');
  if (container) {
    container.innerHTML = `
      <div class="empty-state">
        <div class="empty-state-icon">⚠️</div>
        <p>${message}</p>
        <button class="btn btn-primary mt-4" onclick="location.reload()">Seite neu laden</button>
      </div>
    `;
  }
}

// ============================================
// INITIALIZE ON DOM READY
// ============================================
document.addEventListener('DOMContentLoaded', loadData);
