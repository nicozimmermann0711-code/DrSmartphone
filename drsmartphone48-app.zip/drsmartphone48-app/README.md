# Dr. Smartphone 48 - Premium Booking App

**Klinische Diagnose. Präzise Reparatur.**

Ultra-Premium Booking System mit interaktiven Hotspots für Smartphones, Tablets, Konsolen und Controller.

## 🚀 Features

- **6-Step Booking Flow** - Gerät → Hotspots → Services → Angebot → Termin → Kontakt
- **Device Picker** - 40+ Geräte in 4 Kategorien
- **Interaktive Hotspots** - Klickbare Zonen auf Geräten zur Problemidentifikation
- **Tracking System** - Auftragsverfolgung mit Timeline
- **Customer Portal** - Übersicht aller Aufträge
- **Admin Portal** - Job-Queue und Status-Management
- **Ultra-Dark Premium Design** - Klinisch-edel mit Cyan-Akzenten

## 📁 Projektstruktur

```
drsmartphone48-app/
├── index.html              # Landing Page
├── booking/
│   └── index.html          # 6-Step Booking Flow
├── tracking/
│   └── index.html          # Auftragsverfolgung
├── portal/
│   ├── index.html          # Login
│   ├── customer.html       # Kunden-Dashboard
│   └── admin.html          # Admin-Dashboard
├── assets/
│   ├── brand/              # Logo SVGs
│   └── data/
│       ├── devices.json    # 40+ Geräte mit Hotspots
│       └── services.json   # Services mit Preisen
├── css/
│   ├── tokens.css          # Design Tokens
│   └── styles.css          # Komponenten
└── js/
    └── booking.js          # Booking Logic
```

## 🎨 Design System

### Farben
| Farbe | Hex | Verwendung |
|-------|-----|------------|
| Primary | `#003D82` | Buttons, Borders |
| Accent | `#2BA9B8` | Highlights, CTAs |
| BG Deep | `#060a10` | Hintergrund |
| BG Card | `#0d1520` | Karten |

### Typografie
- **Primary:** Inter
- **Mono:** JetBrains Mono (Preise, Codes)

## 🔧 Deployment

### GitHub Pages
1. Repository erstellen
2. Alle Dateien hochladen
3. Settings → Pages → Branch: main

### Lokaler Test
```bash
# Python
python -m http.server 8000

# Node.js
npx serve .
```

## 📱 Demo-Zugänge

| Rolle | E-Mail | Passwort |
|-------|--------|----------|
| Kunde | kunde@demo.de | demo123 |
| Admin | admin@demo.de | admin123 |

## 🆕 Neues Gerät hinzufügen

1. **devices.json** öffnen
2. Neues Objekt im `devices` Array:

```json
{
  "id": "unique-id",
  "category": "smartphones|tablets|consoles|controllers",
  "brand": "Markenname",
  "model": "Modellname",
  "year": 2024,
  "image": "filename.svg",
  "aspect": "phone|tablet|console|controller",
  "priceFactor": 1.0,
  "hotspots": [
    {
      "id": "screen",
      "label": "Display",
      "type": "rect",
      "x": 0.05,
      "y": 0.02,
      "w": 0.9,
      "h": 0.96,
      "defaultServices": ["screen-repair", "diagnostics"]
    }
  ]
}
```

3. **Hotspot-Koordinaten:** x, y, w, h sind Prozentangaben (0-1)
4. **defaultServices:** Array von Service-IDs aus services.json

## ✅ Testplan

### Hotspot-System
- [ ] Gerät auswählen → Hotspots werden angezeigt
- [ ] Hotspot klicken → Area wird markiert
- [ ] Mehrere Hotspots auswählen
- [ ] Area-Tag entfernen
- [ ] Weiter zu Services → Services vorausgewählt

### Navigation
- [ ] Alle Steps durchlaufen
- [ ] Zurück-Buttons funktionieren
- [ ] Progress-Stepper aktualisiert sich

### Responsive
- [ ] Mobile (320px) - Touch-freundlich
- [ ] Tablet (768px) - Grid passt sich an
- [ ] Desktop (1024px+) - Volle Ansicht

### Accessibility
- [ ] Tab-Navigation durch Hotspots
- [ ] Enter/Space aktiviert Hotspots
- [ ] Focus-States sichtbar
- [ ] ARIA-Labels vorhanden

## 🔮 Zukünftige Erweiterungen (Supabase)

```sql
-- Schema für Backend-Integration
CREATE TABLE devices (
  id UUID PRIMARY KEY,
  category TEXT,
  brand TEXT,
  model TEXT,
  hotspots JSONB,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE bookings (
  id UUID PRIMARY KEY,
  code TEXT UNIQUE,
  device_id UUID REFERENCES devices(id),
  services TEXT[],
  areas TEXT[],
  status TEXT DEFAULT 'received',
  customer JSONB,
  appointment JSONB,
  timeline JSONB[],
  created_at TIMESTAMPTZ DEFAULT NOW()
);
```

## 📄 Lizenz

© 2026 Dr. Smartphone 48. Alle Rechte vorbehalten.

---

**Kontakt:**
- Telefon: 0177 5196018
- E-Mail: drsmartphone48268@gmail.com
- Adresse: Zur Friedrichsburg 8, 48268 Greven
